from project.guild_members.base_guild_member import BaseGuildMember


class Mage(BaseGuildMember):
    ROLE = "Mage"
    SKILL_LEVEL = 1

    def __init__(self, tag: str, gold: int):
        super().__init__(tag, gold, Mage.ROLE, Mage.SKILL_LEVEL)

    def practice(self):
        self.skill_level = min(10, self.skill_level * 2)
